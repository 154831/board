package com.ktdsuniversity.edu.exceptions;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

/**
 * 애플리케이션에서 발생하는 모든 예외들을 이 클래스에서 처리한다.
 * 동작하는 방식은 @Controller 와 매우 유사하다. 
 */
@ControllerAdvice
public class GlobalExceptionHandler {
	/**
	 * PageNotFoundException 발생 시,
	 * viewPageNotFoundErrorPage 메소드가 처리한다.
	 */
	@ExceptionHandler(PageNotFoundException.class)
	public ModelAndView viewPageNotFoundErrorPage(
								PageNotFoundException exception) {
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("error/404");
		modelAndView.addObject("message", exception.getMessage());
				return modelAndView;
	}

	@ExceptionHandler({FileNotExistsException.class, MakeXlsxFileException.class})
	public ModelAndView viewFileErrorPage(FileNotExistsException exception) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("error/500");
		modelAndView.addObject("message", exception.getMessage());
		
		return modelAndView;
	}
	
	@ExceptionHandler(AlreadyUseException.class)
	public ModelAndView viewMemberRegistErrorPage(AlreadyUseException exception) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("member/memberregist");
		modelAndView.addObject("memberVO", exception.getMemberVO());
		modelAndView.addObject("memberVO", exception.getMessage());
		
		return modelAndView;
	}
	
	@ExceptionHandler (UserIdentifyNotMatchException.class)
	public ModelAndView viewUserIdentifyNotMatchErrorPage(
				UserIdentifyNotMatchException exception) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("member/memberlogin");
		modelAndView.addObject("memberVO", exception.getMemberVO());
		modelAndView.addObject("message", exception.getMessage());
		return modelAndView;
	}
}
