package com.ktdsuniversity.edu.exceptions;

public class MakeXlsxFileException extends RuntimeException {
	private static final long serialVersionUID = -2024398098979428921L;

	public MakeXlsxFileException(String message) {
		super(message);
	}
}
